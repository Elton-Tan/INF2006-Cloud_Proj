"""Internals of array-api-extra."""
