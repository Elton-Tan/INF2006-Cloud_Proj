class BaseExtensionTests:
    pass
