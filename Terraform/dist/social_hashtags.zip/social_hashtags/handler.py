# lambda_handlers/social_hashtags/handler.py
import json
import sys
import os

sys.path.insert(0, '/opt/python')
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

from database import SocialMediaDB

def lambda_handler(event, context):
    """
    GET /social/hashtags?limit=20
    Returns trending hashtags by engagement
    """
    try:
        query_params = event.get('queryStringParameters') or {}
        limit = int(query_params.get('limit', 20))
        
        db = SocialMediaDB()
        hashtags = db.get_trending_hashtags(limit)
        
        result = []
        for (tag, count, engagement, avg_eng) in hashtags:
            result.append({
                'hashtag': tag,
                'post_count': count,
                'total_engagement': engagement,
                'avg_engagement': avg_eng
            })
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'hashtags': result})
        }
        
    except Exception as e:
        print(f"Error in hashtags handler: {e}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


# For local testing
if __name__ == "__main__":
    test_event = {
        'queryStringParameters': {'limit': '20'}
    }
    
    result = lambda_handler(test_event, {})
    print(f"Status: {result['statusCode']}")
    print(json.dumps(json.loads(result['body']), indent=2))