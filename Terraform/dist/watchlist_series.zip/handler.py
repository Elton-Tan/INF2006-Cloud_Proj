# watchlist_series/handler.py
import os, json, boto3, pymysql
from datetime import date, datetime
from decimal import Decimal

def _json_default(o):
    if isinstance(o, (datetime, date)): return o.isoformat()
    if isinstance(o, Decimal): return float(o)
    return str(o)

def _cors_headers():
    return {
        "content-type": "application/json",
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET,OPTIONS",
        "access-control-allow-headers": "content-type,authorization",
    }

def lambda_handler(event, _ctx):
    # --- params ---
    qp = (event or {}).get("queryStringParameters") or {}
    gran = (qp.get("range") or "week").lower()
    if gran not in ("day", "week", "month"):
        gran = "week"

    region = os.getenv("AWS_REGION", os.getenv("REGION", "us-east-1"))
    secret_arn = os.environ["DB_SECRET_ARN"]

    # --- db secret ---
    sm = boto3.client("secretsmanager", region_name=region)
    cfg = json.loads(sm.get_secret_value(SecretId=secret_arn)["SecretString"])

    conn = pymysql.connect(
        host=cfg["host"],
        user=cfg["username"],
        password=cfg["password"],
        database=cfg["database"],
        port=int(cfg.get("port", 3306)),
        autocommit=True,
        cursorclass=pymysql.cursors.Cursor,
    )

    # --- choose SQL by granularity (SGT bucketing via CONVERT_TZ) ---
    if gran == "day":
        # last 24h, HOURLY buckets
        sql = """
          SELECT product,
                 DATE_FORMAT(CONVERT_TZ(updated_at,'+00:00','+08:00'), '%%Y-%%m-%%d %%H:00') AS bucket,
                 AVG(price) AS avg_price
          FROM watchlist
          WHERE updated_at >= UTC_TIMESTAMP() - INTERVAL 1 DAY
            AND price IS NOT NULL AND price > 0
          GROUP BY product, bucket
          ORDER BY bucket ASC, product ASC;
        """
    elif gran == "week":
        # last 7 days, DAILY buckets
        sql = """
          SELECT product,
                 DATE_FORMAT(CONVERT_TZ(updated_at,'+00:00','+08:00'), '%%Y-%%m-%%d') AS bucket,
                 AVG(price) AS avg_price
          FROM watchlist
          WHERE updated_at >= UTC_TIMESTAMP() - INTERVAL 7 DAY
            AND price IS NOT NULL AND price > 0
          GROUP BY product, bucket
          ORDER BY bucket ASC, product ASC;
        """
    else:
        # month: last 30 days, DAILY buckets
        sql = """
          SELECT product,
                 DATE_FORMAT(CONVERT_TZ(updated_at,'+00:00','+08:00'), '%%Y-%%m-%%d') AS bucket,
                 AVG(price) AS avg_price
          FROM watchlist
          WHERE updated_at >= UTC_TIMESTAMP() - INTERVAL 30 DAY
            AND price IS NOT NULL AND price > 0
          GROUP BY product, bucket
          ORDER BY bucket ASC, product ASC;
        """

    try:
        with conn.cursor() as cur:
            cur.execute(sql)
            rows = cur.fetchall()  # (product, bucket, avg_price)

        # pivot -> [{bucket, <productA>: n, <productB>: n, ...}, ...]
        by_bucket = {}
        products = set()
        for prod, bucket, avgp in rows:
            products.add(prod or "Unknown")
            key = str(bucket)
            if key not in by_bucket:
                by_bucket[key] = {"bucket": key}
            by_bucket[key][(prod or "Unknown")] = float(avgp) if avgp is not None else None

        data = [by_bucket[k] for k in sorted(by_bucket.keys())]

        return {
            "statusCode": 200,
            "headers": _cors_headers(),
            "body": json.dumps({
                "range": gran,
                "series": data,
                "products": sorted(list(products)),
                "tz": "Asia/Singapore"
            }, default=_json_default),
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": _cors_headers(),
            "body": json.dumps({"error": str(e)}),
        }
