# worker_handler.py (Handler: worker_handler.lambda_handler) -- SQS trigger
import json, os, logging, time
import pymysql, requests, boto3
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from botocore.config import Config as BotoConfig

logging.getLogger().setLevel(logging.INFO)

AWS_REGION = os.getenv("AWS_REGION", os.getenv("REGION", "us-east-1"))
DB_SECRET_ARN = os.getenv("DB_SECRET_ARN")
SCRAPER_SECRET_ARN = os.getenv("SCRAPER_SECRET_ARN")

# NEW: pubsub env
WS_ENDPOINT = os.getenv("WS_ENDPOINT")  # https://...execute-api.../prod
CONN_TABLE = os.getenv("CONN_TABLE")  # e.g., "pubsub"

_boto_cfg = BotoConfig(retries={"max_attempts": 3, "mode": "standard"})
_sm = boto3.client("secretsmanager", region_name=AWS_REGION, config=_boto_cfg)
_ddb = boto3.client("dynamodb", region_name=AWS_REGION)
_api = boto3.client("apigatewaymanagementapi", endpoint_url=WS_ENDPOINT) if WS_ENDPOINT else None

_secret_cache = {}


def _get_secret(secret_id: str):
    if not secret_id:
        return None
    if secret_id in _secret_cache:
        return _secret_cache[secret_id]
    r = _sm.get_secret_value(SecretId=secret_id)
    raw = r.get("SecretString") or r.get("SecretBinary")
    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="ignore")
    try:
        val = json.loads(raw)
    except Exception:
        val = raw
    _secret_cache[secret_id] = val
    return val


def _load_db_cfg():
    s = _get_secret(DB_SECRET_ARN) or {}
    return {
        "host": s.get("host") or os.getenv("DB_HOST"),
        "port": int((s.get("port") or os.getenv("DB_PORT") or 3306)),
        "user": s.get("username") or os.getenv("DB_USER"),
        "password": s.get("password") or os.getenv("DB_PASS"),
        "database": s.get("database") or os.getenv("DB_NAME"),
    }


def _load_scraper_api_key():
    s = _get_secret(SCRAPER_SECRET_ARN)
    if isinstance(s, dict):
        return s.get("Scrapper-API")
    return str(s).strip() if s else None


def _http():
    sess = requests.Session()
    retry = Retry(total=2, backoff_factor=1.5, status_forcelist=(429, 500, 502, 503, 504), allowed_methods=frozenset(["GET"]))
    sess.mount("https://", HTTPAdapter(max_retries=retry))
    return sess


def _scrape(url: str, api_key: str):
    rules = {"summary":"extract product name as 'product', current price as 'price' (number), main product image url as 'image_url', and availability (true if Add to Cart is enabled, false otherwise) as 'availability'"}
    params = {
        "api_key": api_key,
        "url": url,
        "country_code": "sg",
        "stealth_proxy": "true",
        "wait": "1000",
        "block_resources": "true",
        "render_js": "false",
        "ai_extract_rules": json.dumps(rules),
    }
    sess = _http()
    r = sess.get("https://app.scrapingbee.com/api/v1", params=params, timeout=(5, 120))
    if r.status_code >= 400:
        logging.error("ScrapingBee %s for %s — body: %s", r.status_code, url, r.text[:500])
        r.raise_for_status()
    data = r.json()
    item = (data.get("summary") or [{}])[0]
    price = item.get("price")
    try:
        price = float(str(price).replace(",", "")) if price is not None else None
    except Exception:
        price = None
    stock = "In Stock" if item.get("availability") else "Out of Stock"
    product_name = item.get("product") or item.get("product_name")
    image_url = item.get("image_url")
    return {"product": product_name, "price": price, "stock_status": stock, "image_url": image_url}


def _insert_snapshot(conn, url: str, snap: dict):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO watchlist (url, product, price, stock_status, image_url, updated_at)
            VALUES (%s, %s, %s, %s, %s, NOW())
            """,
            (url, snap["product"], snap["price"], snap["stock_status"], snap["image_url"]),
        )


# ---------- NEW: WebSocket push helpers ----------
def _post_to(cid: str, payload_bytes: bytes):
    try:
        _api.post_to_connection(ConnectionId=cid, Data=payload_bytes)
        return True
    except _api.exceptions.GoneException:
        # client disconnected; signal caller to delete from table
        return False


def _delete_conn(pk: str, sk: str):
    try:
        _ddb.delete_item(TableName=CONN_TABLE, Key={"pk": {"S": pk}, "sk": {"S": sk}})
    except Exception:
        logging.exception("Failed to delete stale connection %s/%s", pk, sk)


def _push_row_upserted(user_id: str | None, row: dict):
    if not (_api and CONN_TABLE):
        return
    payload = json.dumps({"type": "watchlist.row_upserted", "row": row}).encode("utf-8")
    if user_id:
        # targeted fan-out
        resp = _ddb.query(
            TableName=CONN_TABLE,
            KeyConditionExpression="pk = :pk",
            ExpressionAttributeValues={":pk": {"S": f"user#{user_id}"}},
            ProjectionExpression="pk, sk, connectionId"
        )
        items = resp.get("Items", [])
    else:
        # broadcast (dev-friendly; fine at small scale)
        resp = _ddb.scan(
            TableName=CONN_TABLE,
            ProjectionExpression="pk, sk, connectionId"
        )
        items = resp.get("Items", [])
    for it in items:
        cid = it.get("connectionId", {}).get("S")
        pk = it.get("pk", {}).get("S")
        sk = it.get("sk", {}).get("S")
        if not cid:
            continue
        ok = _post_to(cid, payload)
        if not ok and pk and sk:
            _delete_conn(pk, sk)
# -------------------------------------------------


def lambda_handler(event, _ctx):
    db = _load_db_cfg()
    api_key = _load_scraper_api_key()

    missing = [k for k, v in [
        ("db.host", db.get("host")),
        ("db.user", db.get("user")),
        ("db.password", db.get("password")),
        ("db.database", db.get("database")),
        ("scraper.api_key", api_key),
    ] if not v]
    if missing:
        logging.error("Missing config: %s", ", ".join(missing))
        raise RuntimeError("Missing required config: " + ", ".join(missing))

    conn = pymysql.connect(
        host=db["host"],
        port=db["port"],
        user=db["user"],
        password=db["password"],
        database=db["database"],
        connect_timeout=5,
        read_timeout=10,
        write_timeout=10,
        autocommit=True,
    )

    failures = []
    for rec in event.get("Records", []):
        rec_id = rec.get("messageId")
        try:
            body = rec.get("body") or "{}"
            payload = json.loads(body)
            url = payload.get("url")
            user_id = payload.get("user_id")  # may be None if enqueue didn't include it
            if not url or not isinstance(url, str):
                raise ValueError("Record has no 'url'")

            logging.info("Scrape start: %s", url)

            # quick outbound probe (best-effort)
            try:
                requests.get("https://httpbin.org/ip", timeout=(3, 5))
            except Exception:
                pass

            snap = _scrape(url, api_key)
            _insert_snapshot(conn, url, snap)

            # Build the row sent to UI (we reuse snap + url + timestamp)
            row = {
                "url": url,
                "product": snap["product"],
                "price": snap["price"],
                "stock_status": snap["stock_status"],
                "image_url": snap["image_url"],
                "updated_at": int(time.time())
            }

            # Push to WebSocket (targeted if user_id present, else broadcast)
            _push_row_upserted(user_id, row)

            logging.info("Scrape done: %s • %s", url, snap.get("stock_status"))
        except Exception:
            logging.exception("Record failed: %s", rec_id)
            failures.append({"itemIdentifier": rec_id})

    try:
        conn.close()
    except Exception:
        pass

    return {"batchItemFailures": failures}
