# lambda_handlers/social_influencers/handler.py
import json
import sys
import os

sys.path.insert(0, '/opt/python')
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

from database import SocialMediaDB

def lambda_handler(event, context):
    """
    GET /social/influencers?limit=10
    Returns top influencers by influence score
    """
    try:
        query_params = event.get('queryStringParameters') or {}
        limit = int(query_params.get('limit', 10))
        
        db = SocialMediaDB()
        influencers = db.get_top_influencers(limit)
        
        result = []
        for (handle, posts, avg_eng, score, products, brands, hashtags, platforms) in influencers:
            result.append({
                'handle': handle,
                'posts': posts,
                'avg_engagement': avg_eng,
                'influence_score': score,
                'products_mentioned': json.loads(products),
                'brands_mentioned': json.loads(brands),
                'top_hashtags': json.loads(hashtags),
                'platforms': json.loads(platforms)
            })
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'influencers': result})
        }
        
    except Exception as e:
        print(f"Error in influencers handler: {e}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


# For local testing
if __name__ == "__main__":
    test_event = {
        'queryStringParameters': {'limit': '5'}
    }
    
    result = lambda_handler(test_event, {})
    print(f"Status: {result['statusCode']}")
    print(json.dumps(json.loads(result['body']), indent=2))