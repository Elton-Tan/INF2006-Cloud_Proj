# handler.py
import os, json, time, logging, math
from datetime import date, timedelta, datetime, timezone
from typing import List, Dict, Tuple
import boto3, pymysql
import pandas as pd
import numpy as np

# ===== ENV =====
SECRET_ARN    = os.environ["DB_SECRET_ARN"]
GEO           = os.getenv("GEO", "SG")
TABLE_NAME    = os.getenv("TABLE_NAME", "google_trends_daily")
CATEGORY      = int(os.getenv("CATEGORY", "0"))
SLEEP_BETWEEN = float(os.getenv("SLEEP_BETWEEN", "1.2"))
MAX_KEYS_PER  = int(os.getenv("MAX_KEYS_PER", "5"))
DAYS_BACK     = int(os.getenv("DAYS_BACK", "400"))
GROUPS_SPEC   = os.getenv("KEYWORD_GROUPS", "antifungal|antifungal cream;spirulina;skin cream")
PROXY         = os.getenv("PROXY", None)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def _load_db_cfg():
    sm = boto3.client("secretsmanager", region_name=os.getenv("AWS_REGION") or os.getenv("REGION"))
    sec = sm.get_secret_value(SecretId=SECRET_ARN)["SecretString"]
    cfg = json.loads(sec)
    return dict(
        host=cfg["host"],
        user=cfg["username"],
        password=cfg["password"],
        db=cfg.get("dbname") or cfg.get("db") or os.getenv("DB_NAME", ""),
        port=int(cfg.get("port", 3306)),
        connect_timeout=10,
        charset="utf8mb4",
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )

def _connect():
    return pymysql.connect(**_load_db_cfg())

def _pytrends_client():
    from pytrends.request import TrendReq
    kwargs = dict(hl="en-US", tz=480)  # SGT
    if PROXY:
        kwargs["proxies"] = {"https": PROXY, "http": PROXY}
    return TrendReq(**kwargs)

def parse_groups(spec: str) -> List[List[str]]:
    groups = []
    for g in [s.strip() for s in spec.split(";") if s.strip()]:
        alts = [a.strip() for a in g.split("|") if a.strip()]
        seen = set(); uniq = []
        for a in alts:
            k = a.lower()
            if k not in seen:
                uniq.append(a); seen.add(k)
        if uniq:
            groups.append(uniq)
    return groups

def group_label(alts: List[str]) -> str:
    s = alts[0]
    return "".join(ch if ch.isalnum() else "_" for ch in s.lower()).strip("_")[:64]

def make_windows(end: date, days_back: int, span_days: int = 90, step_days: int = 60) -> List[Tuple[date, date]]:
    start_total = end - timedelta(days=days_back)
    windows = []
    cur_start = start_total
    while cur_start < end:
        w_end = min(cur_start + timedelta(days=span_days - 1), end)
        windows.append((cur_start, w_end))
        if w_end >= end: break
        cur_start = cur_start + timedelta(days=step_days)
    return windows

def fetch_window(pytrends, terms: List[str], geo: str, cat: int, start: date, end: date) -> pd.DataFrame:
    timeframe = f"{start.isoformat()} {end.isoformat()}"
    pytrends.build_payload(kw_list=terms, cat=cat, timeframe=timeframe, geo=geo, gprop="")
    df = pytrends.interest_over_time()
    if df is None or df.empty:
        return pd.DataFrame(index=pd.DatetimeIndex([], name="date"))
    cols = [c for c in df.columns if c != "isPartial"]
    return df[cols]

def overlap_scale_factor(ref: pd.Series, cur: pd.Series) -> float:
    idx = ref.index.intersection(cur.index)
    if len(idx) < 3: return 1.0
    a = ref.reindex(idx).astype(float)
    b = cur.reindex(idx).astype(float)
    mask = (a > 0) & (b > 0)
    if mask.sum() < 3:
        eps = 1e-6
        ratios = (a + eps) / (b + eps)
        r = float(np.median(ratios.replace([np.inf, -np.inf], np.nan).dropna()))
        return r if np.isfinite(r) and r > 0 else 1.0
    ratios = (a[mask] / b[mask]).replace([np.inf, -np.inf], np.nan).dropna()
    if len(ratios) == 0: return 1.0
    r = float(np.median(ratios))
    return r if np.isfinite(r) and r > 0 else 1.0

def stitch_daily(pytrends, terms: List[str], geo: str, cat: int, end_day: date, days_back: int) -> pd.DataFrame:
    windows = make_windows(end=end_day, days_back=days_back, span_days=90, step_days=60)
    win_series: List[pd.DataFrame] = []
    for i, (ws, we) in enumerate(windows, 1):
        ok = False
        for attempt in range(4):
            try:
                df = fetch_window(pytrends, terms, geo, cat, ws, we)
                ok = True; break
            except Exception as e:
                wait = SLEEP_BETWEEN * (attempt + 1)
                logger.warning(f"window {i}/{len(windows)} fetch error: {e} → sleep {wait:.1f}s")
                time.sleep(wait)
        if not ok:
            df = pd.DataFrame(index=pd.DatetimeIndex([], name="date"))
        win_series.append(df); time.sleep(SLEEP_BETWEEN)

    anchor = terms[0] if terms else None
    merged: pd.DataFrame | None = None

    for df in win_series:
        if df is None or df.empty: continue
        df = df.copy(); df.index = pd.to_datetime(df.index.date)
        if merged is None:
            merged = df; continue
        anchor_col = anchor if anchor in df.columns and anchor in merged.columns else None
        if anchor_col is None:
            for c in terms:
                if c in df.columns and c in merged.columns:
                    anchor_col = c; break
        scale = 1.0
        if anchor_col:
            scale = overlap_scale_factor(merged[anchor_col], df[anchor_col])
        df_scaled = (df * scale).astype(float)
        merged = pd.concat([merged, df_scaled]).groupby(level=0).mean()

    if merged is None: return pd.DataFrame()
    merged = merged.clip(0.0, 100.0).sort_index().asfreq("D").interpolate(limit_direction="both").clip(0.0, 100.0)
    return merged

def groups_from_terms_df(df_terms: pd.DataFrame, groups: List[List[str]]) -> pd.DataFrame:
    out = {}
    for alts in groups:
        label = group_label(alts)
        cols = [c for c in alts if c in df_terms.columns]
        if cols:
            out[label] = df_terms[cols].max(axis=1)  # max across synonyms
    gdf = pd.DataFrame(out); gdf.index.name = "day"
    return gdf

def upsert_rows(conn, table: str, geo: str, gdf: pd.DataFrame) -> int:
    if gdf.empty: return 0
    gdf = gdf.copy(); gdf.index = pd.to_datetime(gdf.index).date
    now_iso = datetime.now(timezone.utc).isoformat()
    sql = f"""
    INSERT INTO `{table}`
      (`day`,`geo`,`keyword_slug`,`keyword_raw`,`interest`,`is_partial`,`ingested_at`)
    VALUES (%s,%s,%s,%s,%s,%s,%s)
    ON DUPLICATE KEY UPDATE
      `interest`=VALUES(`interest`),
      `keyword_raw`=VALUES(`keyword_raw`),
      `is_partial`=VALUES(`is_partial`),
      `ingested_at`=VALUES(`ingested_at`);
    """
    rows = 0
    with conn.cursor() as cur:
        for day, row in gdf.iterrows():
            for slug, val in row.items():
                interest = int(round(float(val)))
                cur.execute(sql, (
                    day.isoformat(), geo, slug, slug.replace("_", " "),
                    interest,
                    1 if (day >= (date.today() - timedelta(days=1))) else 0,
                    now_iso,
                ))
                rows += 1
    return rows

def lambda_handler(_event, _ctx):
    groups = parse_groups(GROUPS_SPEC)
    all_terms, seen = [], set()
    for g in groups:
        for t in g:
            if t.lower() not in seen:
                all_terms.append(t); seen.add(t.lower())
    if not all_terms: 
        return {"statusCode": 400, "body": json.dumps({"error": "no_terms"})}
    if len(all_terms) > MAX_KEYS_PER:
        return {"statusCode": 400, "body": json.dumps({"error": "too_many_terms", "n": len(all_terms)})}

    pytrends = _pytrends_client()
    end_day = date.today()

    df_terms = stitch_daily(pytrends, all_terms, GEO, CATEGORY, end_day, DAYS_BACK)
    if df_terms.empty:
        return {"statusCode": 500, "body": json.dumps({"error": "empty_result"})}

    gdf = groups_from_terms_df(df_terms, groups)
    conn = _connect()
    try:
        n = upsert_rows(conn, TABLE_NAME, GEO, gdf)
    finally:
        try: conn.close()
        except: pass

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "geo": GEO, "rows_upserted": n, "cols": list(gdf.columns),
            "start": str(gdf.index.min()), "end": str(gdf.index.max()),
            "table": TABLE_NAME
        })
    }
