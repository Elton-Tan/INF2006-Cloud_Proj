# database.py
import pymysql
import json
import os
from datetime import datetime

class SocialMediaDB:
    def __init__(self):
        # Get RDS credentials from environment or Secrets Manager
        self.connection = pymysql.connect(
            host=os.environ.get('DB_HOST'),
            user=os.environ.get('DB_USER'),
            password=os.environ.get('DB_PASSWORD'),
            database='spirulinadb',
            cursorclass=pymysql.cursors.DictCursor
        )
    
    
    def init_database(self):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        



        # ============================================
        # NEW TABLE 1: Hashtag Trends
        # ============================================
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS hashtag_trends (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hashtag TEXT,
                post_count INTEGER,
                total_engagement INTEGER,
                avg_engagement REAL,
                discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # ============================================
        # NEW TABLE 2: Influencers
        # ============================================
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS influencers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                handle TEXT UNIQUE,
                posts INTEGER,
                total_engagement INTEGER,
                avg_engagement REAL,
                influence_score REAL,
                products_mentioned TEXT,
                brands_mentioned TEXT,
                top_hashtags TEXT,
                platforms TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # ============================================
        # NEW TABLE 3: Brand Mentions
        # ============================================
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS brand_mentions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                brand TEXT,
                mention_count INTEGER,
                total_engagement INTEGER,
                positive_pct REAL,
                negative_pct REAL,
                neutral_pct REAL,
                platforms TEXT,
                tracked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        # Main posts table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS social_posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT,
                post_id TEXT UNIQUE,
                content TEXT,
                like_count INTEGER,
                comment_count INTEGER,
                engagement_score INTEGER,
                author TEXT,
                timestamp INTEGER,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Sentiment analysis results
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sentiment_analysis (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                post_id TEXT,
                sentiment_label TEXT,
                sentiment_score REAL,
                classification TEXT,
                analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (post_id) REFERENCES social_posts(post_id)
            )
        ''')
        
        # Product/brand mentions
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS product_mentions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                post_id TEXT,
                products TEXT,
                brands TEXT,
                engagement INTEGER,
                detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (post_id) REFERENCES social_posts(post_id)
            )
        ''')
        
# Viral content tracking
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS viral_content (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                post_id TEXT,
                viral_score TEXT,
                engagement INTEGER,
                detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (post_id) REFERENCES social_posts(post_id)
            )
        ''')
        
        # Engagement predictions
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS engagement_predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                post_id TEXT,
                predicted_engagement INTEGER,
                actual_engagement INTEGER,
                prediction_accuracy REAL,
                predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (post_id) REFERENCES social_posts(post_id)
            )
        ''')
        
        # Trending topics
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS trending_topics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic_keywords TEXT,
                topic_weight REAL,
                discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Watchlist for user monitoring
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS watchlist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                social_url TEXT,
                platform TEXT,
                product_name TEXT,
                initial_sentiment REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_posts(self, posts):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for post in posts:
            try:
                cursor.execute('''
                    INSERT OR REPLACE INTO social_posts 
                    (platform, post_id, content, like_count, comment_count, 
                     engagement_score, author, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    post.get('platform'), post.get('post_id'), post.get('content'),
                    post.get('like_count', 0), post.get('comment_count', 0),
                    post.get('like_count', 0) + post.get('comment_count', 0),
                    post.get('author'), post.get('timestamp')
                ))
            except pymysql.IntegrityError:
                pass
        
        conn.commit()
        conn.close()
    
    def save_sentiment_results(self, sentiment_results):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for result in sentiment_results:
            cursor.execute('''
                INSERT INTO sentiment_analysis 
                (post_id, sentiment_label, sentiment_score, classification)
                VALUES (?, ?, ?, ?)
            ''', (
                result['post_id'], result.get('label'), 
                result.get('score'), result.get('classification')
            ))
        
        conn.commit()
        conn.close()
    
    def save_product_mentions(self, mentions):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for mention in mentions:
            cursor.execute('''
                INSERT INTO product_mentions 
                (post_id, products, brands, engagement)
                VALUES (?, ?, ?, ?)
            ''', (
                mention['post_id'], 
                json.dumps(mention.get('products', [])),
                json.dumps(mention.get('brands', [])),
                mention.get('engagement', 0)
            ))
        
        conn.commit()
        conn.close()
    
    def save_viral_content(self, viral_posts):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for post in viral_posts:
            cursor.execute('''
                INSERT INTO viral_content 
                (post_id, viral_score, engagement)
                VALUES (?, ?, ?)
            ''', (
                post['post_id'], post['viral_score'], post['engagement']
            ))
        
        conn.commit()
        conn.close()
    
    def save_engagement_predictions(self, predictions):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for pred in predictions:
            actual = pred.get('actual_engagement', 0)
            predicted = pred.get('predicted_engagement', 0)
            accuracy = 1 - abs(actual - predicted) / max(actual, 1)
            
            cursor.execute('''
                INSERT INTO engagement_predictions 
                (post_id, predicted_engagement, actual_engagement, prediction_accuracy)
                VALUES (?, ?, ?, ?)
            ''', (
                pred['post_id'], predicted, actual, accuracy
            ))
        
        conn.commit()
        conn.close()
    
    def get_all_posts(self):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM social_posts")
        results = cursor.fetchall()
        conn.close()
        return results
    
    def get_posts_by_platform(self, platform):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM social_posts WHERE platform = ?", (platform,))
        results = cursor.fetchall()
        conn.close()
        return results
    
    def get_sentiment_stats(self):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT classification, COUNT(*) as count 
            FROM sentiment_analysis 
            GROUP BY classification
        ''')
        results = cursor.fetchall()
        conn.close()
        return results
    

    def get_top_products(self, limit=10):
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT products, SUM(engagement) as total_engagement 
            FROM product_mentions 
            GROUP BY products 
            ORDER BY total_engagement DESC 
            LIMIT ?
        ''', (limit,))
        results = cursor.fetchall()
        conn.close()
        return results

    
    def save_hashtag_trends(self, hashtags):
        """Save trending hashtags to database"""
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for tag in hashtags:
            cursor.execute('''
                INSERT INTO hashtag_trends 
                (hashtag, post_count, total_engagement, avg_engagement)
                VALUES (?, ?, ?, ?)
            ''', (
                tag['hashtag'],
                tag['post_count'],
                tag['total_engagement'],
                tag['avg_engagement']
            ))
        
        conn.commit()
        conn.close()
    
    def save_influencers(self, influencers):
        """Save influencer data to database"""
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for inf in influencers:
            cursor.execute('''
                INSERT OR REPLACE INTO influencers 
                (handle, posts, total_engagement, avg_engagement, influence_score,
                 products_mentioned, brands_mentioned, top_hashtags, platforms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                inf['handle'],
                inf['posts'],
                inf['total_engagement'],
                inf['avg_engagement'],
                inf['influence_score'],
                json.dumps(inf['products_mentioned']),
                json.dumps(inf['brands_mentioned']),
                json.dumps(inf['top_hashtags']),
                json.dumps(inf['platforms'])
            ))
        
        conn.commit()
        conn.close()
    
    def save_brand_mentions(self, brands):
        """Save brand mention statistics to database"""
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        for brand in brands:
            cursor.execute('''
                INSERT INTO brand_mentions 
                (brand, mention_count, total_engagement, 
                 positive_pct, negative_pct, neutral_pct, platforms)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                brand['brand'],
                brand['mention_count'],
                brand['total_engagement'],
                brand['sentiment']['positive'],
                brand['sentiment']['negative'],
                brand['sentiment']['neutral'],
                json.dumps(brand['platforms'])
            ))
        
        conn.commit()
        conn.close()
    
    # Also add these 3 READ methods:
    
    def get_brand_mentions(self, limit=10):
        """Get brand mention statistics"""
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT brand, mention_count, total_engagement, 
                   positive_pct, negative_pct, neutral_pct, platforms
            FROM brand_mentions 
            ORDER BY mention_count DESC 
            LIMIT ?
        ''', (limit,))
        results = cursor.fetchall()
        conn.close()
        return results
    
    def get_top_influencers(self, limit=10):
        """Get top influencers by influence score"""
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT handle, posts, avg_engagement, influence_score,
                   products_mentioned, brands_mentioned, top_hashtags, platforms
            FROM influencers 
            ORDER BY influence_score DESC 
            LIMIT ?
        ''', (limit,))
        results = cursor.fetchall()
        conn.close()
        return results
    
    def get_trending_hashtags(self, limit=20):
        """Get trending hashtags by engagement"""
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT hashtag, post_count, total_engagement, avg_engagement
            FROM hashtag_trends 
            ORDER BY total_engagement DESC 
            LIMIT ?
        ''', (limit,))
        results = cursor.fetchall()
        conn.close()
        return results
    
    def get_sentiment_by_platform(self):
        """Get sentiment breakdown by platform for API"""
        conn = pymysql.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                sp.platform,
                sa.classification,
                COUNT(*) as count
            FROM sentiment_analysis sa
            JOIN social_posts sp ON sa.post_id = sp.post_id
            GROUP BY sp.platform, sa.classification
        ''')
        
        results = cursor.fetchall()
        conn.close()
        
        # Format results
        platform_sentiment = {}
        for (platform, sentiment, count) in results:
            if platform not in platform_sentiment:
                platform_sentiment[platform] = {
                    'positive': 0, 'negative': 0, 'neutral': 0, 'total': 0
                }
            platform_sentiment[platform][sentiment] = count
            platform_sentiment[platform]['total'] += count
        
        # Calculate percentages
        for platform, stats in platform_sentiment.items():
            total = stats['total']
            if total > 0:
                stats['positive_pct'] = round(stats['positive'] / total * 100, 1)
                stats['negative_pct'] = round(stats['negative'] / total * 100, 1)
                stats['neutral_pct'] = round(stats['neutral'] / total * 100, 1)
        
        return platform_sentiment