# delete_keyword.py
import os, json, logging, base64
from datetime import datetime, timezone
import boto3, pymysql
from botocore.config import Config as BotoConfig

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# -------- Env / Config --------
SECRET_ARN   = os.environ["DB_SECRET_ARN"]
DB_NAME      = os.environ["DB_NAME"]
AWS_REGION   = os.getenv("AWS_REGION") or os.getenv("REGION") or "ap-southeast-1"
DEFAULT_GEO  = os.getenv("DEFAULT_GEO", "sg")
SOFT_DELETE  = os.getenv("SOFT_DELETE", "false").lower() == "true"  # if true -> is_active=0 instead of DELETE

boto_cfg = BotoConfig(retries={"max_attempts": 3, "mode": "standard"})
sm = boto3.client("secretsmanager", region_name=AWS_REGION, config=boto_cfg)

# -------- Helpers --------
def get_db_cfg():
    sec = sm.get_secret_value(SecretId=SECRET_ARN)
    j = json.loads(sec.get("SecretString", "{}"))
    return dict(
        host=j["host"],
        port=int(j.get("port", 3306)),
        user=j["username"],
        password=j["password"],
        db=DB_NAME,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )

def respond(status: int, body):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body, default=str),
    }

def _parse_params(event):
    # API Gateway proxy: queryStringParameters for DELETE
    qs = event.get("queryStringParameters") or {}
    # Allow body (rare, but some clients send JSON in DELETE)
    if not qs and event.get("body"):
        try:
            body = event["body"]
            if event.get("isBase64Encoded"):
                body = base64.b64decode(body).decode("utf-8", "ignore")
            j = json.loads(body)
            qs = {k: v for k, v in j.items() if v is not None}
        except Exception:
            pass
    return qs

# -------- Lambda --------
def lambda_handler(event, context):
    """
    HTTP DELETE /trends/keywords?id=<id>  OR  /trends/keywords?slug=<term>  (alias: keyword=<term>)
    Optional: &geo=sg  (used only to narrow slug deletes if needed)

    If SOFT_DELETE=true -> UPDATE ... SET is_active=0 WHERE ...
    Else -> DELETE FROM trend_keywords WHERE ...
    """
    try:
        qs = _parse_params(event)

        id_raw   = (qs.get("id") or "").strip()
        slug_raw = (qs.get("slug") or qs.get("keyword") or "").strip()
        geo      = (qs.get("geo") or DEFAULT_GEO or "sg").lower().strip()[:8]

        if not id_raw and not slug_raw:
            return respond(400, {"error": "missing_id_or_slug"})

        # Build SQL
        # prefer ID if present; otherwise delete by slug/keyword (exact match)
        where_sql = ""
        params    = []

        if id_raw:
            # Allow numeric or string IDs (in case your table uses VARCHAR PK)
            # Most setups: auto-inc INT id
            where_sql = "id = %s"
            params.append(id_raw)
        else:
            # Delete by keyword; geo narrowing optional (uncomment to enforce geo match)
            where_sql = "keyword = %s"
            params.append(slug_raw)
            # If you want to scope by geo as well, add:
            # where_sql += " AND geo = %s"
            # params.append(geo)

        if SOFT_DELETE:
            sql = f"UPDATE trend_keywords SET is_active = 0 WHERE {where_sql} LIMIT 1"
        else:
            sql = f"DELETE FROM trend_keywords WHERE {where_sql} LIMIT 1"

        # Execute
        cfg = get_db_cfg()
        with pymysql.connect(**cfg) as conn, conn.cursor() as cur:
            cur.execute(sql, params)
            affected = cur.rowcount

        if affected < 1:
            return respond(404, {
                "ok": False,
                "deleted": 0,
                "soft_delete": SOFT_DELETE,
                "reason": "not_found"
            })

        return respond(200, {
            "ok": True,
            "deleted": 0 if SOFT_DELETE else 1,
            "soft_updated": 1 if SOFT_DELETE else 0,
            "soft_delete": SOFT_DELETE,
            "where": {"id": id_raw or None, "slug": slug_raw or None, "geo": geo},
            "ts_utc": datetime.now(timezone.utc).isoformat().replace("+00:00","Z")
        })

    except Exception as e:
        logger.exception("delete_keyword failed")
        return respond(500, {"error": "internal_error", "detail": str(e)})
